"""Reply to comments in linked discussion groups when GrantBek is addressed.

Only fires when the bot is @mentioned or replied to (see bot.filters), and
only in allowed groups if ALLOWED_GROUP_IDS is configured. Replies are threaded
via reply_to so they appear under the right comment.
"""
from __future__ import annotations

import logging
import re

from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import ContextTypes

from config import settings
from bot.i18n import get_lang, t
from services import faq as faq_svc
from services import grant_search as gs
from services import llm

logger = logging.getLogger(__name__)


def _strip_mention(text: str) -> str:
    return re.sub(rf"@{re.escape(settings.bot_username)}", "", text, flags=re.IGNORECASE).strip()


async def handle_group_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    msg = update.effective_message
    if msg is None:
        return

    chat_id = update.effective_chat.id
    if settings.allowed_group_ids and chat_id not in settings.allowed_group_ids:
        return

    user = update.effective_user
    lang = await get_lang(user.id, user.language_code if user else None) if user else "en"

    raw = msg.text or msg.caption or ""
    question = _strip_mention(raw)
    if not question:
        await msg.reply_text(t("welcome", lang), parse_mode=ParseMode.MARKDOWN)
        return

    faq = await faq_svc.find_faq(question)
    grants = await gs.search_grants(question, limit=3)

    if settings.llm_enabled and (faq or grants):
        answer = await llm.answer(question, grants, faq, lang)
        if answer:
            await msg.reply_text(answer, disable_web_page_preview=True)
            return

    if faq:
        await msg.reply_text(faq_svc.format_faq_response(faq, lang), parse_mode=ParseMode.HTML)
        return
    if grants:
        await msg.reply_text(
            gs.format_grant_card(grants[0], lang),
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True,
        )
        return
    await msg.reply_text(t("no_results", lang))
